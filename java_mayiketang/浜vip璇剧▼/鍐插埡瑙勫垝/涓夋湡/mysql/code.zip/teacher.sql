/*
 Navicat Premium Data Transfer

 Source Server         : aliyun57
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 47.112.44.148:3306
 Source Schema         : mysqladv

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 06/04/2021 18:57:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `number` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`number`) USING BTREE,
  INDEX `idx_name`(`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES (1, 'Jack', '源码系列');
INSERT INTO `teacher` VALUES (3, 'Mark', '并发编程');
INSERT INTO `teacher` VALUES (9, 'James', 'Redis');
INSERT INTO `teacher` VALUES (15, 'King', 'JVM');
INSERT INTO `teacher` VALUES (21, 'DaFei', 'MySQL');

SET FOREIGN_KEY_CHECKS = 1;
