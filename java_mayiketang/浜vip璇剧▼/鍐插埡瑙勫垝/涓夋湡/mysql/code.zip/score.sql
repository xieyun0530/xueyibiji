/*
 Navicat Premium Data Transfer

 Source Server         : aliyun57
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 47.112.44.148:3306
 Source Schema         : mysqladv

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 06/04/2021 18:57:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `number` int(11) NOT NULL COMMENT '学号',
  `subject` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '科目',
  `score` tinyint(4) NULL DEFAULT NULL COMMENT '成绩',
  PRIMARY KEY (`number`, `subject`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '学生成绩表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES (20200901, '数据结构和算法', 88);
INSERT INTO `score` VALUES (20200901, '网络通信原理', 90);
INSERT INTO `score` VALUES (20200902, '数据结构和算法', 95);
INSERT INTO `score` VALUES (20200902, '网络通信原理', 89);
INSERT INTO `score` VALUES (20200903, '离散数学', 70);

SET FOREIGN_KEY_CHECKS = 1;
