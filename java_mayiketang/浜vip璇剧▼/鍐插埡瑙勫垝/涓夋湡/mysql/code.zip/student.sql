/*
 Navicat Premium Data Transfer

 Source Server         : aliyun57
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 47.112.44.148:3306
 Source Schema         : mysqladv

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 06/04/2021 18:57:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `number` int(11) NOT NULL AUTO_INCREMENT COMMENT '学号',
  `name` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `major` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '专业',
  PRIMARY KEY (`number`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20200905 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '学生信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (20200901, 'Jack', '网络工程');
INSERT INTO `student` VALUES (20200902, 'Mark', '计算机科学');
INSERT INTO `student` VALUES (20200903, 'James', '计算机科学');
INSERT INTO `student` VALUES (20200904, 'King', '软件工程');

SET FOREIGN_KEY_CHECKS = 1;
